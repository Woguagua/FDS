#include<stdio.h>
#include<stdlib.h>
#define INF 1000000			//define a number that is very large so it can be seen as infinite
#define MaxN 500            //the max number of stations

struct Vertex
{
    int to;
    int back;
};							//the number of bicycles that should be taken to the present vertex and back to the start
typedef struct Vertex *vertex;

int w[MaxN][MaxN];			//record the distance between two vertexes

void print(int *path, int S)		//print the shortest path from start to the present vertex
{
    if(path[S]==-1)			//print "0" when the path gets to the start
    {
        printf("%d",S);
        return;
    }
    else
        print(path,path[S]);	//print the former verdex of present vertex S
    
    printf("->%d",S);
    return;
}

vertex Findbike(int index,int *path,int cap,int *s)		//find the number of bikes that should be taken to the present vertex and back to the start along the shortese path
{
    vertex v=(vertex)malloc(sizeof(struct Vertex));
    if(index==0)			//none bikes should be taken to the start and back to itself
    {
        v->to=0;
        v->back=0;
    }
    else
    {
        int m,n;
        m=Findbike(path[index],path,cap,s)->to;			//m is the number of bikes that should be taken to the former vertex along the shortest path
        n=Findbike(path[index],path,cap,s)->back;		//n is the number of bikes that should be taken back to the start along the shortest path
        
        if(s[index]>=cap/2)								//if bikes should be taken from the present vertex
        {
            v->to = m;
            v->back = n+s[index]-cap/2;
        }
        else											//if bikes should be added to the present vertex
        {
            if(cap/2-s[index]>=m)							//if bikes taken from the former vertex are not enough to make the present vertex half full
            {
                v->to = m+cap/2-s[index]-n;
                v->back = 0;
            }
            else											//if bikes taken from the former vertex are enough to make the present vertex half full
            {
                v->to = m;
                v->back= n-cap/2+s[index];
            }
        }
    }
    return v;											//return the number of bikes that should be taken to the present vertex and back to the start along the shortese path
}

int main()
{
    int d[MaxN],visit[MaxN];			//d[] is the shortest distance from every index to the start,visit[] is used to sign whether a vertex has been visited or not
    int s[MaxN];					    //the number of bikes at every vertex
    int cap,N,S,M;					//cap is the capacity of every vertex,N is the total number of vertexes,S is the problem vertex,M is the number of roads
    int i,j;
    int S1,S2;
    int path[MaxN];					//path is the former vertex of the present vertex in the shortest path
    
    for(i=0;i<MaxN;i++)
    {
        d[i]=INF;
        visit[i]=0;
        s[i]=0;
        path[i]=0;
    }								//initialize
    d[0]=0;
    path[0]=-1;						//it is convenient to stop printing
    
    for(i=0;i<MaxN;i++)
    {
        for(j=0;j<MaxN;j++)
        {
            w[i][j]=INF;
        }
        w[i][i]=0;
    }							    //initialize
    
    printf("Please enter the the maximum capacity of each station,the total number of stations,the index of the problem station and the number of roads in the first line\n\n");
    scanf("%d %d %d %d",&cap,&N,&S,&M);
    
    printf("Please enter the current number of bikes at each station respectively in the second line\n\n");
    for(i=1;i<=N;i++)
        scanf("%d",&s[i]);				//get the input
    
    printf("Please enter the stations and time taken to move between them in the following lines\n\n") ;
    for(i=0;i<M;i++)
    {
        scanf("%d %d",&S1,&S2);
        scanf("%d",&w[S1][S2]);
        w[S2][S1]=w[S1][S2];
    }							    //get the distance between two vertexes because the distance from S1 to S2 is the same as from S2 to S1
    
    for(i=1;i<=M;i++)
    {
        d[i]=w[0][i];
    } 								//the initial shortest distance from the start to every vertex
    
    for(i=0;i<=N;i++)
    {
        int dmin=INF;
        int present=-1;
        for(j=1;j<=N;j++)
        {
            if(!visit[j]&&d[j]<dmin)
            {
                dmin=d[j];				//find the present shortest distance
                present=j;				//find the vertex of present shortest distance
            }
        }
        
        visit[present]=1;			//sign the vertex to show it has been visited
        
        for(j=1;j<=N;j++)
        {
            if(!visit[j])			//among all the vertexes that have not been visited
            {
                if(d[j]>d[present]+w[present][j])						//if there is a shorter path from start to vertex j
                {
                    d[j]=d[present]+w[present][j];						//renew the shortest distance from the start to vertex j
                    path[j]=present;									//renew the former vertex of vertex j in the shortest path
                }
                else if(d[j]==d[present]+w[present][j]) 				//if there is more than one shortest path from start to vertex j
                {
                    vertex v1,v2;
                    v1=Findbike(present,path,cap,s);
                    v2=Findbike(j,path,cap,s);
                    
                    
                    if(s[j]>=cap/2)										//if bikes should be taken from the present vertex
                    {
                        v1->back += s[j]-cap/2;
                    }
                    else												//if bikes should be added to the present vertex
                    {
                        if(cap/2-s[j]>=v1->back)								//if bikes taken from the former vertex are not enough to make the present vertex half full
                        {
                            v1->to += cap/2-s[j]-v1->back;
                            v1->back = 0;
                        }
                        else												//if bikes taken from the former vertex are enough to make the present vertex half full
                        {
                            v1->back += s[j]-cap/2;
                        }
                    }
                    
                    
                    if(v1->to<v2->to)									//compare the numbers of bikes that should be taken to vertex j along the two shortest paths
                    {
                        path[j]=present;								//choose the path that fewer bikes are needed to take to vertex j and renew the shortest path
                    }
                    else if(v1->to==v2->to)								//if the numbers of bikes that shoud be taken to vertex j are the same
                    {
                        if(v1->back<v2->back)
                            path[j]=present;								//choose the path that fewer bikes are needed to take back to the start and renew the shortest path
                    }
                }
            }
        } 
    }
    
    vertex v;
    v=Findbike(S,path,cap,s);										//get the numbers of the bikes that should be taken to the problem vertex and back to the start along the shortest path
    printf("%d ",v->to);
    print(path,S);													//print the shortest path
    printf(" %d",v->back);
}
