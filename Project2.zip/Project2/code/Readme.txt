main.c contains our program.
You can just follow the hint text and enter the required information to get the result.
The input format is as the same as the requirement in PTA.Don’t forget the space between each two number when you are entering.
Executable file is also in this zip file.
Thanks in advance for your reading and your precious comment.