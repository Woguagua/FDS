#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#define even 2
#define odd 1
double iterative(double X,int N);
double recursive(double X,int N);
double Nmultiplication(double X,int N);
double (*Algorithm)(double X,int N);

//methematically,the recursive algorithm and the iterative one are 
//base on the same theory:to calculate X^N,
//if N is an even number,then X^N = X^(N/2) * X^(N/2);
//if N is an odd number,then X^N = X^((N-1)/2) *  X^((N-1)/2) * X

double recursive(double X,int N){
	double result;
	if(N == 1)	return X;//when N = 1,stop the recursion
	if(N%2 == 0)	result = pow(recursive(X,N/2),2);//when N is an even number
	else			result = pow(recursive(X,(N-1)/2),2)*X;//when N is an odd number
	return result;
}

double Nmultiplication(double X,int N){
	double result = 1;
	int i;
	for(i = 0;i<N;i++)	result *= X;//multiply X for N times
	return result;
}

//In the iterative algorithm,we process N first.
//If N is an even number,then we divide N by 2,
//else if it is an odd number,we divide N-1 by 2,
//and see that whether the result is an even number or an odd number.
//We continue to do so until N become 1,and mark down everytime after division
//whether the result is an even number or an odd number,and store them into record[].
//Then,we can start to calculate the result.With the record,we know that each time
//whether we should do result*result( X^(N/2)*X^(N/2)=X^N ) or result*result*X( X^((N-1)/2)*X^((N-1)/2)*X=X^N )
double iterative(double X,int N){
    int record[20];
    int i = 0;
    double result = X;
    while(N>1){
        if(N%2 == 0){
            N = N/2;
            record[i++] = even;
        }
        else{
            N = (N-1)/2;
            record[i++] = odd;
        }
    }//record whether N is odd number or even number after division
    while(i>0){
        if(record[--i] == even)     result *= result;//N is an even number,then X^(N/2)*X^(N/2)=X^N
        else                        result *= result*X;//N is an odd number,then X^((N-1)/2)*X^((N-1)/2)*X=X^N
    }
    return result;
}

//test program
int main(){
	int Iterations;//how many times to run the function
	double X;
	int N;
	int state = 1;
	int mode;
	int times;
	clock_t start, stop;
	while(1){
		times = 0;
		printf("1:Begin 0:exit\nEnter:");
		scanf("%d",&state);//choose to continue or exit the program
		if(state == 0)		break;
		printf("Choose Algorithm 1:N-1Multiplication  2:Iterative  3:Recursive\nEnter:");
		scanf("%d",&mode);
		switch(mode){
			case 1 : Algorithm = Nmultiplication;break;
			case 2 : Algorithm = iterative;break;
			case 3 : Algorithm = recursive;break;
			default : continue;
		}//choose which algorithm to test
		printf("Enter X:");
		scanf("%lf",&X);
		printf("Enter N:");
		scanf("%d",&N);
		printf("Enter Iterations(K):");
		scanf("%d",&Iterations);
		start = clock();
		while(times++<Iterations)		Algorithm(X,N);
		stop = clock();
		double totaltime = (double)(stop - start)/CLK_TCK;//the total time after running K times
		printf("Total Time:%lf s\nDuration:%lf ms\n",totaltime,totaltime*1000/Iterations);//Duration represent the average time 
		printf("-------------------------------------\n");
	}
}
